#!/usr/bin/python
# -*- coding: utf-8 -*-
import os, sys, xbmcgui, xbmcplugin, xbmcaddon, urllib2, re
xbmcplugin.setContent(handle=int(sys.argv[1]),content='songs')

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_ =  xbmcaddon.Addon()
addon_icon_ = fix_encoding(addon_.getAddonInfo('icon'))

def add_item(url,infolabels,img):
    listitem = xbmcgui.ListItem(infolabels['title'],iconImage=img,thumbnailImage=img)
    listitem.setInfo('audio',infolabels)
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),url,listitem)

def requesthandler(url):
    try:
        opener = urllib2.build_opener()
        opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'),('Accept-Language', 'de-de,de;q=0.8,en-us;q=0.5,en;q=0.3'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')]
        response = opener.open(url,timeout=30)
        data = response.read()
        response.close()
        return data
    except Exception as err:
        xbmcgui.Dialog().ok( 'Error !',str( err ) )
        sys.exit(0)

def regex_group(content,addon_icon):
    for title,url in re.findall('<div class="wrapper">[\s\S]*?<h1>(.+?)<\/h1>[\s\S]*?192 kbps[\s\S]*?href="(.+?)"',content):
        add_item(url,{ 'title':'[COLOR blue]' + title.upper() + '[/COLOR]'},addon_icon)

regex_group(requesthandler('https://stream.sunshine-live.de'),addon_icon_)
xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ]),succeeded=True,updateListing=False,cacheToDisc=False)