IAGL Supplementary Databases

The contents of the databases (xml files) in this folder, and only the databases in this folder, are released under the Attribution-NonCommercial 4.0 International license. This allows for non-commercial use of the data as long as credit is given and that derivative works (works based on the CC licensed data) are also made available under the same license.

For more information, see the LICENSE.txt file included in this folder.