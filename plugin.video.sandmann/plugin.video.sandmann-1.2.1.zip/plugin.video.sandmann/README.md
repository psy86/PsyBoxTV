# The Kodi _Sandmann_ Addon

This is the repository for the _Kodi Sandmann Plugin_.
[Kodi](https://kodi.tv) is a famous media center software.
This plugin enables you to access video content from
[sandmann.de](http://www.sandmann.de) from within Kodi.

## Bugs

If you find a bug, please submit it to GitHub's
[bug tracker](https://github.com/sorax/plugin.video.sandmann/issues)

## Contributors

- [sorax](https://github.com/sorax)
