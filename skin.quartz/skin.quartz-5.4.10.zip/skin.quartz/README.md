# Quartz 


Quartz skin for KODI 18 (Leia)

Follow the link below for the latest news and information about this classic skin for KODI.

https://forum.kodi.tv/showthread.php?tid=331334
