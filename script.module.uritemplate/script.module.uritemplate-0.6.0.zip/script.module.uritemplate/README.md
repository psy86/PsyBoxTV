script.module.uritemplate
=======================

An XBMC addon that wraps up the uritemplates python module

See the source code page for official documentation and usage: https://github.com/uri-templates/uritemplate-py
