# context.copytostorage
A context menu add-on for [Kodi](https://kodi.tv) which enables you to copy movies, songs, etc.. into your devices
 
![alt tag](https://github.com/AbelTesfaye/context.copytostorage/blob/master/resources/screenshot-01.png?raw=true)
