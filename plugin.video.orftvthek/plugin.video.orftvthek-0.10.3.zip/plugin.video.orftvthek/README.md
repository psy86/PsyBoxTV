ORF TVthek KODI Addon
=======
ORF TVthek is an addon that gives you access to the ORF TVthek Video Platform.


Supported platforms
-------------------
Windows, Linux , Android and OSX


Current Features
----------------
* Livestream
* All Shows
* Schedule Search
* HTTP Stream H264 (Stable)
* Search Function
* Missed Shows
* Blacklist Shows
* JSON(Service API V3) or HTML Scraper
* Restart Livestream - inputstream.adaptive needed


Known Issues
------------
* you tell me


Legal
-----
This addon provides access to videos on the ORF TVthek Website but is not endorsed, certified or otherwise approved in any way by ORF.

Icons
-----
https://uxwing.com