def format_bold(text):
    return "[B]" + text + "[/B]"
