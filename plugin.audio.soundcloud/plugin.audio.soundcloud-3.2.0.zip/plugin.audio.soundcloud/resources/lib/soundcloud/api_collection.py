class ApiCollection:
    type = 0
    items = []
    load = []
    next_href = ""
